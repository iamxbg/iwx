package com.ray.test;

import org.junit.Test;

import com.ray.pojo.menu.Button;
import com.ray.pojo.menu.Menu;
import com.ray.pojo.menu.ViewButton;
import com.ray.service.MenuService;
import com.ray.util.WeiXinParamesUtil;

public class MenuTest {
	@Test
	public void testDeleteMenu(){
		MenuService ms = new MenuService();
		String accessToken = "ZOh-xh3rMQL3zQyJkTTpLRn1ScpKWIGrgV_bpvMQRqOVucRJ0pBnsvzBAQ2YwzLRbPRQcTLsVe24s7ZcFZcumT8fcyAGUwjgViKBr9kh5-sOsuI1GqbyWHveo7NamlTx93s27hSbiKRCyb7S4khNYZZVuZf0b_n_grt-1Y25R8GKB0SFapmwwOJi8Ii_5ggxyhKepFBoDntoOMY9ObOBPA";
		ms.deleteMenu(accessToken, WeiXinParamesUtil.agentId);
	}
	
	@Test
	public void testCreateMenu() {
		// 1.组装菜单
		MenuService ms = new MenuService();
		// Menu menu=ms.getMenu();
		Menu menu = new Menu();
		ViewButton button = new ViewButton();
		button.setName("报表系统");
		button.setType("view");
		button.setUrl("http://www.baidu.com");
		menu.setButton(new Button[] { button });
		// 2.获取access_token:根据企业id和应用密钥获取access_token
		// String
		// accessToken=WeiXinUtil.getAccessToken(WeiXinParamesUtil.corpId,
		// WeiXinParamesUtil.agentSecret).getToken();
		String accessToken = "ZOh-xh3rMQL3zQyJkTTpLRn1ScpKWIGrgV_bpvMQRqOVucRJ0pBnsvzBAQ2YwzLRbPRQcTLsVe24s7ZcFZcumT8fcyAGUwjgViKBr9kh5-sOsuI1GqbyWHveo7NamlTx93s27hSbiKRCyb7S4khNYZZVuZf0b_n_grt-1Y25R8GKB0SFapmwwOJi8Ii_5ggxyhKepFBoDntoOMY9ObOBPA";
		System.out.println("accessToken:" + accessToken);

		// 3.创建菜单
		ms.createMenu(accessToken, menu, WeiXinParamesUtil.agentId);
	}
}
