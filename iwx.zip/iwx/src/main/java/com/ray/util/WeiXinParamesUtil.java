package com.ray.util;
/**
 * 微信参数
 * @author shirayner
 *
 */
public class WeiXinParamesUtil {
	//1.微信参数
	//token
	public final static String token = "ray";
	// encodingAESKey
	public final static String encodingAESKey = "z2W9lyOAR1XjY8mopEmiSqib0TlBZzCFiCLp6IdS2Iv";
	//企业ID
	public final static String corpId = "ww7938e5bbc3f81de5";

	//应用的凭证密钥
	public final static String agentSecret = "3JrpCeZoXfgGaPfAY3ZX12R9bMFsRs1E-UVUSMt_bFM";
	//通讯录秘钥
	public final static String contactsSecret = "1m_9XP62YrXjSiYtL5ThbexiLVWBThukiK5sH7wm1TM";
	//打卡的凭证密钥
	public final static String checkInSecret = "LLTMcHo5otbgXMF8a5HY0ThTrQLqfkVmU0F6wX_gRIc";
	//审批的凭证密钥
	public final static String approveSecret = "6X7Ft0hIZXY6Q2IfbWGLBFvLmNfJkzBZ6k3efWZE0-8";
	
	
	//企业应用的id，整型。可在应用的设置页面查看
	public final static int agentId = 1000002;


}
