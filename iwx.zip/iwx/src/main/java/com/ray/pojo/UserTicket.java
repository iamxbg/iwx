/**
 * 
 */
package com.ray.pojo;

/**@desc  : 
 * 
 * @author: shirayner
 * @date  : 2017年9月14日 下午12:38:58
 */
public class UserTicket {
    private String user_ticket;

	/**
	 * @return the user_ticket
	 */
	public String getUser_ticket() {
		return user_ticket;
	}

	/**
	 * @param user_ticket the user_ticket to set
	 */
	public void setUser_ticket(String user_ticket) {
		this.user_ticket = user_ticket;
	}
 
    
}
