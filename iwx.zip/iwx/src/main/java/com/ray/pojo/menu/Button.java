package com.ray.pojo.menu;  
  
/**
 * @desc  : 按钮的基类 
 * 
 * @author: shirayner
 * @date  : 2017-8-20 下午9:29:43
 */
public class Button {  
    private String name;  
  
    public String getName() {  
        return name;  
    }  
  
    public void setName(String name) {  
        this.name = name;  
    }  
}  