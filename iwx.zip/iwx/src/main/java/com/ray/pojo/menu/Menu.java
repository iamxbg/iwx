package com.ray.pojo.menu;  
  
/**
 * @desc  : 菜单 
 * 
 * @author: shirayner
 * @date  : 2017-8-20 下午9:30:31
 */
public class Menu {  
    private Button[] button;  
  
    public Button[] getButton() {  
        return button;  
    }  
  
    public void setButton(Button[] button) {  
        this.button = button;  
    }  
}  