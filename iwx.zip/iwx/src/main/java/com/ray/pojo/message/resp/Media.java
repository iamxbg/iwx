package com.ray.pojo.message.resp;

/**
 * @desc  : 图片、语音
 * 
 * @author: shirayner
 * @date  : 2017-8-17 下午1:52:19
 */
public class Media {
    
    private String MediaId;

    public String getMediaId() {
        return MediaId;
    }

    public void setMediaId(String mediaId) {
        MediaId = mediaId;
    }
}